// app/(dashboard)/types.ts
export interface WalletData {
  balance: number;
  usdtBalance: number;
  preferredCurrency: 'NGN' | 'USDT';
}

export interface CampaignForm {
  title: string;
  videoUrl: string;
  budget: string;
  currency: 'NGN' | 'USDT';
  platforms: string[];
  hashtags: string;
  directions: string;
  categories: string[];
  ctaUrl: string;
}

export interface FormErrors {
  title?: string;
  videoUrl?: string;
  budget?: string;
  platforms?: string;
  categories?: string;
}

export const NGN_PER_THOUSAND_VIEWS = 3000;
export const USDT_PER_THOUSAND_VIEWS = 1.85;

export const PLATFORM_OPTIONS = [
  { id: 'tiktok', label: 'TikTok', icon: 'tiktok' },
  { id: 'instagram', label: 'Instagram Reels', icon: 'instagram' },
  { id: 'youtube', label: 'YouTube Shorts', icon: 'youtube' },
  { id: 'facebook', label: 'Facebook Reels', icon: 'facebook' },
  { id: 'twitter', label: 'X (Twitter)', icon: 'twitter' },
] as const;

export const CATEGORY_OPTIONS = [
  'Fashion & Style',
  'Beauty & Makeup',
  'Tech & Gadgets',
  'Gaming',
  'Food & Cooking',
  'Travel & Adventure',
  'Fitness & Health',
  'Business & Finance',
  'Education & Learning',
  'Entertainment',
  'Comedy',
  'Sports',
  'Music & Dance',
  'DIY & Crafts',
  'Lifestyle',
  'Motivation & Inspiration',
  'Pets & Animals',
  'Parenting & Family',
  'Automotive',
  'Real Estate',
] as const;
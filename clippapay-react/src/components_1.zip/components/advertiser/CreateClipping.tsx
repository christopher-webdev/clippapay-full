// src/components/advertiser/create_clipping.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

// Types
interface WalletData {
  balance: number;
  usdtBalance: number;
  preferredCurrency: 'NGN' | 'USDT';
}

interface CampaignForm {
  title: string;
  videoUrl: string;
  budget: string;
  currency: 'NGN' | 'USDT';
  platforms: string[];
  hashtags: string;
  directions: string;
  categories: string[];
  ctaUrl: string;
}

interface FormErrors {
  title?: string;
  videoUrl?: string;
  budget?: string;
  platforms?: string;
  categories?: string;
}

// Constants
const API_BASE = import.meta.env.VITE_API_URL || 'https://clippapay.com/api';
const NGN_PER_THOUSAND_VIEWS = 3000;
const USDT_PER_THOUSAND_VIEWS = 1.85;

const PLATFORM_OPTIONS = [
  { id: 'tiktok', label: 'TikTok', icon: 'fab fa-tiktok' },
  { id: 'instagram', label: 'Instagram Reels', icon: 'fab fa-instagram' },
  { id: 'youtube', label: 'YouTube Shorts', icon: 'fab fa-youtube' },
  { id: 'facebook', label: 'Facebook Reels', icon: 'fab fa-facebook' },
  { id: 'twitter', label: 'X (Twitter)', icon: 'fab fa-twitter' },
];

const CATEGORY_OPTIONS = [
  'Fashion & Style',
  'Beauty & Makeup',
  'Tech & Gadgets',
  'Gaming',
  'Food & Cooking',
  'Travel & Adventure',
  'Fitness & Health',
  'Business & Finance',
  'Education & Learning',
  'Entertainment',
  'Comedy',
  'Sports',
  'Music & Dance',
  'DIY & Crafts',
  'Lifestyle',
  'Motivation & Inspiration',
  'Pets & Animals',
  'Parenting & Family',
  'Automotive',
  'Real Estate',
];

export default function CreateClippingCampaign() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [walletLoading, setWalletLoading] = useState(true);
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [form, setForm] = useState<CampaignForm>({
    title: '',
    videoUrl: '',
    budget: '',
    currency: 'NGN',
    platforms: [],
    hashtags: '',
    directions: '',
    categories: [],
    ctaUrl: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [estimatedViews, setEstimatedViews] = useState(0);
  const [activeStep, setActiveStep] = useState(1);

  // Fetch wallet balance on mount
  useEffect(() => {
    fetchWalletData();
  }, []);

  // Calculate estimated views when budget or currency changes
  useEffect(() => {
    const budgetNum = parseFloat(form.budget) || 0;
    if (budgetNum > 0) {
      const ratePerView = form.currency === 'NGN' 
        ? NGN_PER_THOUSAND_VIEWS / 1000 
        : USDT_PER_THOUSAND_VIEWS / 1000;
      const views = Math.floor(budgetNum / ratePerView);
      setEstimatedViews(views);
    } else {
      setEstimatedViews(0);
    }
  }, [form.budget, form.currency]);

  const getToken = () => {
    return localStorage.getItem('userToken');
  };

  const fetchWalletData = async () => {
    try {
      const token = getToken();
      if (!token) throw new Error('No authentication token');

      const response = await axios.get(`${API_BASE}/wallet`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setWallet(response.data);
      setForm(prev => ({ 
        ...prev, 
        currency: response.data.preferredCurrency || 'NGN' 
      }));
    } catch (error) {
      console.error('Wallet fetch error:', error);
      alert('Failed to load wallet balance');
    } finally {
      setWalletLoading(false);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!form.title.trim()) {
      newErrors.title = 'Campaign title is required';
    } else if (form.title.length < 5) {
      newErrors.title = 'Title must be at least 5 characters';
    } else if (form.title.length > 100) {
      newErrors.title = 'Title must be less than 100 characters';
    }

    if (!form.videoUrl.trim()) {
      newErrors.videoUrl = 'Video URL is required';
    } else {
      try {
        new URL(form.videoUrl);
        if (!form.videoUrl.match(/\.(mp4|mov|avi|mkv|webm)$/i) && 
            !form.videoUrl.includes('youtube.com') && 
            !form.videoUrl.includes('youtu.be') && 
            !form.videoUrl.includes('vimeo.com') && 
            !form.videoUrl.includes('drive.google.com')) {
          newErrors.videoUrl = 'Please enter a valid video URL (MP4, YouTube, Vimeo, or Google Drive)';
        }
      } catch {
        newErrors.videoUrl = 'Please enter a valid URL';
      }
    }

    const budgetNum = parseFloat(form.budget);
    if (!form.budget) {
      newErrors.budget = 'Budget is required';
    } else if (isNaN(budgetNum) || budgetNum <= 0) {
      newErrors.budget = 'Please enter a valid budget amount';
    } else {
      const minBudget = form.currency === 'NGN' ? 3000 : 1.85;
      if (budgetNum < minBudget) {
        newErrors.budget = `Minimum budget is ${form.currency === 'NGN' ? '₦3,000' : '$1.85 USDT'}`;
      }

      const availableBalance = form.currency === 'NGN' ? wallet?.balance || 0 : wallet?.usdtBalance || 0;
      if (budgetNum > availableBalance) {
        newErrors.budget = `Insufficient ${form.currency} balance`;
      }
    }

    if (form.platforms.length === 0) {
      newErrors.platforms = 'Select at least one platform';
    }

    if (form.categories.length === 0) {
      newErrors.categories = 'Select at least one category';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      alert('Please fix the errors in the form');
      return;
    }

    setLoading(true);

    try {
      const token = getToken();
      if (!token) throw new Error('No authentication token');

      const budgetNum = parseFloat(form.budget);
      const payload = {
        title: form.title.trim(),
        videoUrl: form.videoUrl.trim(),
        budget: budgetNum,
        currency: form.currency,
        platforms: form.platforms,
        hashtags: form.hashtags.split(',').map(tag => tag.trim()).filter(Boolean),
        directions: form.directions.split('\n').filter(line => line.trim()),
        categories: form.categories,
        ctaUrl: form.ctaUrl.trim() || undefined,
        estimatedViews,
        costPerThousand: form.currency === 'NGN' ? NGN_PER_THOUSAND_VIEWS : USDT_PER_THOUSAND_VIEWS,
      };

      const response = await axios.post(`${API_BASE}/campaigns/clipping`, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const userConfirmed = window.confirm(
        '🎉 Campaign Created!\n\nYour clipping campaign is now active. Clippers can start joining and submitting proofs.\n\nWould you like to manage this campaign?'
      );

      if (userConfirmed) {
        navigate(`/dashboard/advertiser/clipping_campaign_detail?id=${response.data.campaignId}`);
      } else {
        navigate('/dashboard/advertiser/my_clipping_campaigns');
      }
    } catch (error: any) {
      console.error('Campaign creation error:', error);
      alert(error.response?.data?.message || 'Failed to create campaign. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const togglePlatform = (platformId: string) => {
    setForm(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platformId)
        ? prev.platforms.filter(id => id !== platformId)
        : [...prev.platforms, platformId],
    }));
    if (errors.platforms) {
      setErrors(prev => ({ ...prev, platforms: undefined }));
    }
  };

  const toggleCategory = (category: string) => {
    setForm(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category],
    }));
    if (errors.categories) {
      setErrors(prev => ({ ...prev, categories: undefined }));
    }
  };

  const formatCurrency = (amount: number, currency: 'NGN' | 'USDT') => {
    return currency === 'NGN' 
      ? `₦${amount.toLocaleString()}`
      : `$${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
  };

  return (
    <div className="create-clipping-campaign">
      <div className="campaign-container">
        {/* Header */}
        <div className="page-header">
          <button onClick={() => navigate(-1)} className="back-btn">
            <i className="fas fa-arrow-left"></i> Back
          </button>
          <h1 className="page-title">Create Clipping Campaign</h1>
          <p className="page-subtitle">Turn your video into viral clips</p>
        </div>

        {/* Wallet Info */}
        <div className="wallet-card">
          <div className="wallet-gradient">
            <div className="wallet-header">
              <i className="fas fa-wallet"></i>
              <h3>Your Wallet</h3>
            </div>
            
            {walletLoading ? (
              <div className="text-center py-4">
                <div className="spinner"></div>
              </div>
            ) : wallet ? (
              <div className="wallet-balances">
                <div className="balance-item">
                  <p className="balance-label">NGN Balance</p>
                  <p className="balance-value">₦{wallet.balance.toLocaleString()}</p>
                </div>
                <div className="balance-divider"></div>
                <div className="balance-item">
                  <p className="balance-label">USDT Balance</p>
                  <p className="balance-value">${wallet.usdtBalance.toLocaleString()}</p>
                </div>
              </div>
            ) : (
              <p className="text-red-200">Failed to load wallet</p>
            )}
          </div>
        </div>

        {/* Info Card */}
        <div className="info-card">
          <i className="fas fa-info-circle text-primary"></i>
          <p>
            Creators will download your video from the provided link and create engaging clips. 
            You pay {form.currency === 'NGN' ? '₦3,000' : '$1.85 USDT'} per 1,000 views generated.
          </p>
        </div>

        {/* Main Form */}
        <div className="form-card">
          {/* Step Indicator */}
          <div className="step-indicator">
            {[1, 2, 3].map((step) => (
              <React.Fragment key={step}>
                <div className={`step-dot ${activeStep >= step ? 'active' : ''}`}>
                  <span>{step}</span>
                </div>
                {step < 3 && <div className={`step-line ${activeStep > step ? 'active' : ''}`}></div>}
              </React.Fragment>
            ))}
          </div>

          {/* Step 1: Basic Info */}
          {activeStep === 1 && (
            <div className="step-content">
              <div className="form-group">
                <label>Campaign Title *</label>
                <input
                  type="text"
                  className={errors.title ? 'error' : ''}
                  value={form.title}
                  onChange={(e) => {
                    setForm(prev => ({ ...prev, title: e.target.value }));
                    if (errors.title) setErrors(prev => ({ ...prev, title: undefined }));
                  }}
                  placeholder="e.g., Summer Fashion Lookbook Clips"
                  maxLength={100}
                />
                {errors.title && <span className="error-text">{errors.title}</span>}
                <span className="char-count">{form.title.length}/100</span>
              </div>

              <div className="form-group">
                <label>Video URL *</label>
                <div className="url-input-wrapper">
                  <i className="fas fa-link"></i>
                  <input
                    type="url"
                    className={errors.videoUrl ? 'error' : ''}
                    value={form.videoUrl}
                    onChange={(e) => {
                      setForm(prev => ({ ...prev, videoUrl: e.target.value }));
                      if (errors.videoUrl) setErrors(prev => ({ ...prev, videoUrl: undefined }));
                    }}
                    placeholder="https://youtube.com/watch?v=... or direct video URL"
                  />
                </div>
                {errors.videoUrl && <span className="error-text">{errors.videoUrl}</span>}
                <small>Supported: YouTube, Vimeo, Google Drive, or direct MP4 links</small>
              </div>

              <button className="btn-next" onClick={() => setActiveStep(2)}>
                Next: Budget & Platforms <i className="fas fa-arrow-right"></i>
              </button>
            </div>
          )}

          {/* Step 2: Budget & Platforms */}
          {activeStep === 2 && (
            <div className="step-content">
              <div className="form-group">
                <label>Payment Currency</label>
                <div className="currency-selector">
                  <button
                    className={form.currency === 'NGN' ? 'active' : ''}
                    onClick={() => setForm(prev => ({ ...prev, currency: 'NGN' }))}
                  >
                    ₦ NGN
                  </button>
                  <button
                    className={form.currency === 'USDT' ? 'active' : ''}
                    onClick={() => setForm(prev => ({ ...prev, currency: 'USDT' }))}
                  >
                    $ USDT
                  </button>
                </div>
              </div>

              <div className="form-group">
                <label>Budget *</label>
                <div className="budget-input-wrapper">
                  <span className="currency-symbol">
                    {form.currency === 'NGN' ? '₦' : '$'}
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    className={errors.budget ? 'error' : ''}
                    value={form.budget}
                    onChange={(e) => {
                      setForm(prev => ({ ...prev, budget: e.target.value }));
                      if (errors.budget) setErrors(prev => ({ ...prev, budget: undefined }));
                    }}
                    placeholder="0.00"
                  />
                </div>
                {errors.budget && <span className="error-text">{errors.budget}</span>}
                
                {estimatedViews > 0 && (
                  <div className="estimate-box">
                    <p className="estimate-label">Estimated Views</p>
                    <p className="estimate-value">{estimatedViews.toLocaleString()} views</p>
                    <p className="estimate-rate">
                      Rate: {form.currency === 'NGN' ? '₦3,000' : '$1.85 USDT'}/1k views
                    </p>
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Platforms *</label>
                <div className="platforms-grid">
                  {PLATFORM_OPTIONS.map((platform) => (
                    <button
                      key={platform.id}
                      className={`platform-btn ${form.platforms.includes(platform.id) ? 'active' : ''}`}
                      onClick={() => togglePlatform(platform.id)}
                    >
                      <i className={platform.icon}></i>
                      <span>{platform.label}</span>
                    </button>
                  ))}
                </div>
                {errors.platforms && <span className="error-text">{errors.platforms}</span>}
              </div>

              <div className="button-group">
                <button className="btn-back" onClick={() => setActiveStep(1)}>
                  <i className="fas fa-arrow-left"></i> Back
                </button>
                <button className="btn-next" onClick={() => setActiveStep(3)}>
                  Next: Guidelines <i className="fas fa-arrow-right"></i>
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Guidelines */}
          {activeStep === 3 && (
            <div className="step-content">
              <div className="form-group">
                <label>Hashtags</label>
                <input
                  type="text"
                  value={form.hashtags}
                  onChange={(e) => setForm(prev => ({ ...prev, hashtags: e.target.value }))}
                  placeholder="#viral, #trending, #fashion"
                />
                <small>Separate hashtags with commas</small>
              </div>

              <div className="form-group">
                <label>Editing Directions</label>
                <textarea
                  rows={5}
                  value={form.directions}
                  onChange={(e) => setForm(prev => ({ ...prev, directions: e.target.value }))}
                  placeholder="• Use trending audio&#10;• Add captions&#10;• Keep clips under 30 seconds&#10;• Highlight key moments"
                />
              </div>

              <div className="form-group">
                <label>Categories *</label>
                <div className="categories-container">
                  {CATEGORY_OPTIONS.map((category) => (
                    <button
                      key={category}
                      className={`category-chip ${form.categories.includes(category) ? 'active' : ''}`}
                      onClick={() => toggleCategory(category)}
                    >
                      {category}
                    </button>
                  ))}
                </div>
                {errors.categories && <span className="error-text">{errors.categories}</span>}
              </div>

              <div className="form-group">
                <label>Call-to-Action URL (Optional)</label>
                <input
                  type="url"
                  value={form.ctaUrl}
                  onChange={(e) => setForm(prev => ({ ...prev, ctaUrl: e.target.value }))}
                  placeholder="https://yourwebsite.com/product"
                />
              </div>

              <div className="button-group">
                <button className="btn-back" onClick={() => setActiveStep(2)}>
                  <i className="fas fa-arrow-left"></i> Back
                </button>
                <button 
                  className={`btn-submit ${loading ? 'loading' : ''}`}
                  onClick={handleSubmit}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <div className="spinner-small"></div> Creating...
                    </>
                  ) : (
                    <>
                      Create Campaign <i className="fas fa-check-circle"></i>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Summary Card */}
        {estimatedViews > 0 && activeStep === 3 && (
          <div className="summary-card">
            <h3>Campaign Summary</h3>
            <div className="summary-row">
              <span>Budget:</span>
              <strong>{formatCurrency(parseFloat(form.budget) || 0, form.currency)}</strong>
            </div>
            <div className="summary-row">
              <span>Estimated Views:</span>
              <strong>{estimatedViews.toLocaleString()}</strong>
            </div>
            <div className="summary-row">
              <span>Platforms:</span>
              <strong>{form.platforms.length}</strong>
            </div>
            <div className="summary-row">
              <span>Categories:</span>
              <strong>{form.categories.length}</strong>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .create-clipping-campaign {
          min-height: 100vh;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px;
        }

        .campaign-container {
          max-width: 800px;
          margin: 0 auto;
        }

        .page-header {
          margin-bottom: 24px;
        }

        .back-btn {
          background: rgba(255,255,255,0.2);
          border: none;
          padding: 8px 16px;
          border-radius: 8px;
          color: white;
          cursor: pointer;
          margin-bottom: 16px;
        }

        .page-title {
          color: white;
          font-size: 28px;
          margin: 0 0 8px 0;
        }

        .page-subtitle {
          color: rgba(255,255,255,0.9);
          margin: 0;
        }

        .wallet-card {
          margin-bottom: 20px;
          border-radius: 16px;
          overflow: hidden;
        }

        .wallet-gradient {
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          padding: 20px;
          color: white;
        }

        .wallet-header {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 16px;
        }

        .wallet-balances {
          display: flex;
          justify-content: space-between;
        }

        .balance-item {
          flex: 1;
        }

        .balance-label {
          font-size: 12px;
          opacity: 0.9;
          margin: 0 0 4px 0;
        }

        .balance-value {
          font-size: 20px;
          font-weight: bold;
          margin: 0;
        }

        .balance-divider {
          width: 1px;
          background: rgba(255,255,255,0.3);
          margin: 0 16px;
        }

        .info-card {
          background: white;
          padding: 16px;
          border-radius: 12px;
          display: flex;
          gap: 12px;
          margin-bottom: 20px;
          border: 1px solid #e5e7eb;
        }

        .info-card i {
          color: #6366f1;
          font-size: 20px;
        }

        .info-card p {
          margin: 0;
          color: #4b5563;
          line-height: 1.5;
        }

        .form-card {
          background: white;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .step-indicator {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 32px;
        }

        .step-dot {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: #f3f4f6;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #e5e7eb;
        }

        .step-dot.active {
          background: #ff6b35;
          border-color: #ff6b35;
          color: white;
        }

        .step-line {
          flex: 1;
          height: 2px;
          background: #e5e7eb;
          margin: 0 8px;
        }

        .step-line.active {
          background: #ff6b35;
        }

        .form-group {
          margin-bottom: 24px;
        }

        .form-group label {
          display: block;
          font-weight: 600;
          margin-bottom: 8px;
          color: #374151;
        }

        .form-group input,
        .form-group textarea {
          width: 100%;
          padding: 12px;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          font-size: 14px;
        }

        .form-group input.error,
        .form-group textarea.error {
          border-color: #ef4444;
        }

        .error-text {
          color: #ef4444;
          font-size: 12px;
          margin-top: 4px;
          display: block;
        }

        .char-count {
          font-size: 12px;
          color: #9ca3af;
          text-align: right;
          display: block;
          margin-top: 4px;
        }

        .url-input-wrapper {
          display: flex;
          align-items: center;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          padding: 0 12px;
        }

        .url-input-wrapper i {
          color: #9ca3af;
        }

        .url-input-wrapper input {
          border: none;
          padding: 12px 8px;
        }

        .currency-selector {
          display: flex;
          gap: 12px;
        }

        .currency-selector button {
          flex: 1;
          padding: 10px;
          border: 1px solid #e5e7eb;
          background: white;
          border-radius: 8px;
          cursor: pointer;
        }

        .currency-selector button.active {
          background: #6366f1;
          color: white;
          border-color: #6366f1;
        }

        .budget-input-wrapper {
          display: flex;
          align-items: center;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          padding: 0 12px;
        }

        .currency-symbol {
          font-size: 18px;
          font-weight: bold;
          margin-right: 8px;
        }

        .budget-input-wrapper input {
          border: none;
          padding: 12px 0;
          flex: 1;
        }

        .estimate-box {
          background: #eff6ff;
          padding: 12px;
          border-radius: 8px;
          margin-top: 12px;
        }

        .estimate-label {
          font-size: 12px;
          color: #ff6b35;
          margin: 0 0 4px 0;
        }

        .estimate-value {
          font-size: 18px;
          font-weight: bold;
          color: #1e3a8a;
          margin: 0 0 4px 0;
        }

        .estimate-rate {
          font-size: 12px;
          color: #6b7280;
          margin: 0;
        }

        .platforms-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
          gap: 12px;
        }

        .platform-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 10px;
          border: 1px solid #e5e7eb;
          background: white;
          border-radius: 8px;
          cursor: pointer;
        }

        .platform-btn.active {
          background: #eef2ff;
          border-color: #ff6b35;
          color: #ff6b35;
        }

        .categories-container {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .category-chip {
          padding: 6px 12px;
          background: #f3f4f6;
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          font-size: 13px;
          cursor: pointer;
        }

        .category-chip.active {
          background: #eef2ff;
          border-color: #ff6b35;
          color: #ff6b35;
        }

        .button-group {
          display: flex;
          gap: 12px;
          margin-top: 24px;
        }

        .btn-next,
        .btn-submit {
          flex: 1;
          padding: 12px;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .btn-back {
          padding: 12px 24px;
          background: #f3f4f6;
          border: none;
          border-radius: 8px;
          cursor: pointer;
        }

        .btn-submit {
          background: #10b981;
        }

        .btn-submit.loading {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .summary-card {
          background: white;
          margin-top: 20px;
          padding: 20px;
          border-radius: 12px;
          border: 1px solid #e5e7eb;
        }

        .summary-card h3 {
          margin: 0 0 16px 0;
        }

        .summary-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 12px;
        }

        .spinner {
          width: 24px;
          height: 24px;
          border: 3px solid rgba(255,255,255,0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin: 0 auto;
        }

        .spinner-small {
          width: 16px;
          height: 16px;
          border: 2px solid rgba(255,255,255,0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        @media (max-width: 640px) {
          .create-clipping-campaign {
            padding: 12px;
          }
          
          .form-card {
            padding: 16px;
          }
          
          .platforms-grid {
            grid-template-columns: 1fr;
          }
          
          .button-group {
            flex-direction: column;
          }
        }
      `}</style>
    </div>
  );
}
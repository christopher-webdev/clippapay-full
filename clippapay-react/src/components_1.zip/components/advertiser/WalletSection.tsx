import React, {
  useEffect,
  useState,
  ChangeEvent,
  FormEvent,
} from 'react';
import axios from 'axios';
import { Dialog } from '@headlessui/react';
import {
  UploadCloud,
  ArrowDownCircle,
  FileText,
  Landmark,
  CircleDollarSign,
  Info,
  X
} from 'lucide-react';

import { getUserFromToken } from '@/utils/getUserFromToken';

type Deposit = {
  _id: string;
  amount: number;
  receiptUrl: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
};

type Withdrawal = {
  _id: string;
  amount: number;
  method: 'bank' | 'usdt';
  bankName?: string;
  accountNumber?: string;
  accountName?: string;
  usdtAddress?: string;
  usdtNetwork?: string;
  status: 'pending' | 'completed' | 'declined';
  createdAt: string;
};

// Declare PaystackPop type
declare global {
  interface Window {
    PaystackPop: any;
  }
}

export default function WalletSection() {
  // balances
  const [balance, setBalance] = useState(0);
  const [escrow, setEscrow] = useState(0);

  // lists
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);

  // loading / messages
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);

  // Deposit modal
  const [showDepModal, setShowDepModal] = useState(false);
  const [depAmt, setDepAmt] = useState(0);
  const [depFile, setDepFile] = useState<File | null>(null);
  // const [depMethod, setDepMethod] = useState<'bank' | 'usdt' | 'paystack'>('bank');
  const [depMethod, setDepMethod] = useState<'bank' | 'usdt' | 'paystack'>('paystack');


  // Withdrawal modal
  const [showWdrModal, setShowWdrModal] = useState(false);
  const [wdrAmt, setWdrAmt] = useState(0);
  const [wdrMethod, setWdrMethod] = useState<'bank' | 'usdt'>('bank');
  const [wdrBankName, setWdrBankName] = useState('');
  const [wdrAcctNum, setWdrAcctNum] = useState('');
  const [wdrAcctName, setWdrAcctName] = useState('');
  const [wdrUsdtAddr, setWdrUsdtAddr] = useState('');
  const [wdrUsdtNet, setWdrUsdtNet] = useState('');

  // Bank details for display
  const [bankDetails, setBankDetails] = useState({
    bankName: '',
    accountNumber: '',
    accountName: ''
  });

  // Paystack states
  const [email, setEmail] = useState('');
  const [reference, setReference] = useState('');
  // const publicKey = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY || 'pk_test_051a719bd448e98834a3994149ce4f61552ff1f0';

  // FIX: Hardcode the public key for now
  const publicKey = 'pk_test_051a719bd448e98834a3994149ce4f61552ff1f0';

  const withdrawable = balance;

  // Paystack payment function
  const initializePaystackPayment = () => {
    if (!window.PaystackPop) {
      setMsg('Payment processor not loaded. Please refresh and try again.');
      return;
    }

    if (!email || depAmt < 5000) {
      setMsg('Please enter a valid email and amount (minimum ₦5,000).');
      return;
    }

    const paystack = window.PaystackPop.setup({
      key: publicKey,
      email: email,
      amount: depAmt * 100, // Convert to kobo
      ref: reference,
      currency: 'NGN',
      onSuccess: (transaction: any) => {
        setMsg('Payment successful! Verifying...');
        verifyPaystackPayment(transaction.reference);
      },
      onCancel: () => {
        setMsg('Payment was cancelled.');
      },
      onClose: () => {
        setMsg('Payment window closed.');
      }
    });

    paystack.openIframe();
  };

  // Verify Paystack payment
  const verifyPaystackPayment = async (ref: string) => {
    setLoading(true);
    try {
      await axios.post('/wallet/verify-paystack', { reference: ref });
      setMsg('Deposit successful! Balance updated.');
      setShowDepModal(false);
      setDepAmt(0);
      fetchAll();
    } catch (err: any) {
      console.error(err);
      setMsg(err.response?.data?.error || 'Payment verification failed. If charged, contact support.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch bank details, wallet data, and user email
  useEffect(() => {
    const fetchBankDetails = async () => {
      try {
        const res = await axios.get('/wallet/bank-details');
        setBankDetails(res.data);
      } catch (err) {
        console.error('Failed to fetch bank details:', err);
      }
    };



    fetchBankDetails();

    fetchAll();

    // const interval = setInterval(fetchAll, 30000); // 30s refresh

    // return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const user = getUserFromToken();
    if (user?.email) {
      setEmail(user.email);
    } else {
      setMsg('Email not found in token. Please re-login.');
    }
    const fetchBankDetails = async () => {
      try {
        const res = await axios.get('/wallet/bank-details');
        setBankDetails(res.data);
      } catch (err) {
        console.error('Failed to fetch bank details:', err);
      }
    };

    fetchBankDetails();
    fetchAll();
    getUserFromToken()

  }, []);

  // Generate unique reference when deposit modal opens
  useEffect(() => {
    if (showDepModal) {
      setReference(`dep_${new Date().getTime()}_${Math.random().toString(36).substr(2, 9)}`);
    }
  }, [showDepModal]);

  // Fetch wallet, deposits, withdrawals
  const fetchAll = async () => {
    setLoading(true);
    try {
      const [wRes, dRes, wdRes] = await Promise.all([
        axios.get<{ balance: number; escrowLocked: number }>('/wallet'),
        axios.get<Deposit[]>('/wallet/deposits'),
        axios.get<Withdrawal[]>('/withdrawals'),
      ]);
      setBalance(wRes.data.balance);
      setEscrow(wRes.data.escrowLocked);
      setDeposits(dRes.data);
      setWithdrawals(wdRes.data);
    } catch (e) {
      console.error(e);
      setMsg('Failed to load wallet data.');
    } finally {
      setLoading(false);
    }
  };

  // Submit manual deposit (bank or usdt)
  const submitDeposit = async (e: FormEvent) => {
    e.preventDefault();

    if (depAmt < 10000) {
      setMsg('Minimum deposit amount is ₦10,000.');
      return;
    }

    if (depAmt <= 0 || !depFile) {
      setMsg('Please enter an amount and upload your receipt.');
      return;
    }

    const form = new FormData();
    form.append('amount', depAmt.toString());
    form.append('receipt', depFile);
    form.append('paymentMethod', depMethod);

    try {
      await axios.post('/wallet/deposits', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMsg('Deposit request sent – awaiting approval.');
      setShowDepModal(false);
      setDepAmt(0);
      setDepFile(null);
      fetchAll();
    } catch (err: any) {
      console.error(err);
      setMsg(err.response?.data?.error || 'Deposit submission failed.');
    }
  };

  // Submit withdrawal
  const submitWithdraw = async (e: FormEvent) => {
    e.preventDefault();
    if (wdrAmt <= 0 || wdrAmt > withdrawable) {
      setMsg('Invalid withdrawal amount.');
      return;
    }
    const payload: any = { amount: wdrAmt, paymentMethod: wdrMethod };
    if (wdrMethod === 'bank') {
      if (!wdrBankName || !wdrAcctNum || !wdrAcctName) {
        setMsg('Bank details are required.');
        return;
      }
      payload.bankName = wdrBankName;
      payload.accountNumber = wdrAcctNum;
      payload.accountName = wdrAcctName;
    } else {
      if (!wdrUsdtAddr || !wdrUsdtNet) {
        setMsg('USDT address & network required.');
        return;
      }
      payload.usdtAddress = wdrUsdtAddr;
      payload.usdtNetwork = wdrUsdtNet;
    }
    try {
      await axios.post('/withdrawals', payload);
      setMsg('Withdrawal requested – admin will process within 30 mins.');
      setShowWdrModal(false);
      setWdrAmt(0);
      fetchAll();
    } catch (err: any) {
      console.error(err);
      setMsg(err.response?.data?.error || 'Withdrawal request failed.');
    }
  };

  if (loading) return <p className="text-center py-8">Loading…</p>;

  return (
    <div className="space-y-6 p-4 max-w-4xl mx-auto">
      {msg && (
        <div className={`px-4 py-2 rounded ${msg.includes('success') ? 'bg-green-100 text-green-800' :
          msg.includes('fail') ? 'bg-red-100 text-red-800' :
            'bg-blue-100 text-blue-800'
          }`}>
          {msg}
        </div>
      )}

      {/* Balances */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-sm font-medium text-gray-500">Available Balance</p>
          <p className="mt-2 text-2xl font-bold">₦{balance.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-sm font-medium text-gray-500">In Escrow</p>
          <p className="mt-2 text-2xl font-bold">₦{escrow.toLocaleString()}</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <button
          onClick={() => setShowDepModal(true)}
          className="px-5 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition flex items-center gap-2"
        >
          <ArrowDownCircle className="w-5 h-5" />
          Deposit Funds
        </button>

        {/* <button
          onClick={() => setShowWdrModal(true)}
          disabled={withdrawable <= 0}
          className="px-5 py-2 rounded-lg bg-green-600 text-white font-medium hover:bg-green-700 transition flex items-center gap-2 disabled:opacity-50"
        >
          <UploadCloud className="w-5 h-5" />
          Withdraw Funds
        </button> */}
      </div>

      {/* Deposit Requests */}
      <section>
        <h2 className="text-lg font-semibold mb-2">
          Your Deposit Requests
        </h2>
        <ul className="space-y-2">
          {deposits.length ? deposits.map((d, idx) => (
            <li
              key={d._id}
              className="flex items-center justify-between bg-white rounded-lg p-4 shadow"
            >
              <div className="flex items-center gap-4">
                <FileText className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium">₦{d.amount.toLocaleString()}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(d.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span
                  className={`px-2 py-1 text-xs font-semibold rounded-full ${d.status === 'pending'
                    ? 'bg-yellow-100 text-yellow-800'
                    : d.status === 'approved'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                    }`}
                >
                  {d.status.charAt(0).toUpperCase() + d.status.slice(1)}
                </span>
                <a
                  href={d.receiptUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-blue-600 hover:underline text-sm"
                >
                  View Receipt
                </a>
              </div>
            </li>
          )) : (
            <p className="text-gray-500">No deposit requests yet.</p>
          )}
        </ul>
      </section>

      {/* Withdrawal Requests */}
      <section>
        <h2 className="text-lg font-semibold mb-2">
          Your Withdrawal Requests
        </h2>
        <ul className="space-y-2">
          {withdrawals.length ? withdrawals.map((w, idx) => (
            <li
              key={w._id}
              className="flex items-center justify-between bg-white rounded-lg p-4 shadow"
            >
              <div className="flex items-center gap-4">
                <FileText className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium">₦{w.amount.toLocaleString()}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(w.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <span
                className={`px-2 py-1 text-xs font-semibold rounded-full ${w.status === 'pending'
                  ? 'bg-yellow-100 text-yellow-800'
                  : w.status === 'completed'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                  }`}
              >
                {w.status.charAt(0).toUpperCase() + w.status.slice(1)}
              </span>
            </li>
          )) : (
            <p className="text-gray-500">No withdrawal requests yet.</p>
          )}
        </ul>
      </section>


      {/* Deposit Modal */}
      <Dialog open={showDepModal} onClose={() => setShowDepModal(false)} className="relative z-50">
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <Dialog.Panel className="fixed inset-0 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center">
              <Dialog.Title className="text-xl font-semibold">Add Funds</Dialog.Title>
              <button onClick={() => setShowDepModal(false)}><X className="w-6 h-6" /></button>
            </div>

            <form onSubmit={depMethod !== 'paystack' ? submitDeposit : (e) => e.preventDefault()} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                <div className="grid grid-cols-2 gap-3">
                  {(['paystack', 'bank'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setDepMethod(m)}
                      className={`flex items-center justify-center gap-2 p-3 rounded-lg border transition-all ${depMethod === m
                        ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-sm'
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                    >
                      {m === 'bank' ? (
                        <>
                          <Landmark className="w-5 h-5" />
                          Bank Transfer
                        </>
                      ) : (
                        <>
                          <CircleDollarSign className="w-5 h-5" />
                          Paystack - Coming Soon
                        </>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {depMethod === 'bank' && (
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <p className="text-sm text-blue-800">
                      Transfer to our bank account and upload receipt for verification.
                    </p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Bank:</span> {bankDetails.bankName}</p>
                    <p><span className="font-medium">Account:</span> {bankDetails.accountNumber}</p>
                    <p><span className="font-medium">Name:</span> {bankDetails.accountName}</p>
                  </div>
                </div>
              )}

              {depMethod === 'paystack' && (
                <div className="bg-green-50 border border-green-100 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <Info className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <p className="text-sm text-green-800">
                      Pay securely via Paystack (cards, bank, etc.). Funds added instantly on success.
                    </p>
                  </div>
                  <p className="text-xs text-gray-500">
                    Minimum: ₦10,000. Email: {email}
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Amount (₦)</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₦</span>
                  <input
                    type="number"
                    min="10000"
                    value={depAmt || ''}
                    onChange={e => setDepAmt(parseFloat(e.target.value) || 0)}
                    required
                    className="pl-8 pr-4 py-2 block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">Minimum deposit: ₦5,000</p>
              </div>

              {depMethod !== 'paystack' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Upload Receipt</label>
                  <div
                    className={`relative border-2 border-dashed rounded-lg p-4 text-center ${depFile ? 'bg-blue-50 border-blue-500' : 'bg-gray-50 border-gray-300'
                      }`}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const file = e.dataTransfer.files?.[0];
                      if (file && (file.type.startsWith('image/') || file.type === 'application/pdf')) {
                        setDepFile(file);
                      } else {
                        setMsg('Please upload an image or PDF file.');
                      }
                    }}
                  >
                    <UploadCloud className="mx-auto w-8 h-8 text-gray-400" />
                    <input
                      type="file"
                      accept="image/*,application/pdf"
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        const file = e.target.files?.[0] ?? null;
                        if (file && (file.type.startsWith('image/') || file.type === 'application/pdf')) {
                          setDepFile(file);
                        } else {
                          setMsg('Please upload an image or PDF file.');
                        }
                      }}
                      required
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    {depFile ? (
                      <p className="mt-2 text-sm text-blue-600 font-medium">
                        Selected: {depFile.name}
                      </p>
                    ) : (
                      <p className="mt-2 text-sm text-gray-600">
                        Drag receipt here or click to upload
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowDepModal(false)}
                  className="px-5 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition"
                >
                  Cancel
                </button>
                {depMethod !== 'paystack' ? (
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition flex items-center gap-2"
                    disabled={loading}
                  >
                    {loading ? 'Processing...' : 'Submit Deposit'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={initializePaystackPayment}
                    disabled={loading || !email || depAmt < 500000000000000000000000}
                    className="px-5 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition flex items-center gap-2 disabled:opacity-50"
                  >
                    Pay with Paystack
                  </button>
                )}
              </div>
            </form>
          </div>
        </Dialog.Panel>
      </Dialog>

      {/* Withdrawal Modal (unchanged) */}
      <Dialog
        open={showWdrModal}
        onClose={() => setShowWdrModal(false)}
        className="relative z-50"
      >
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <Dialog.Panel className="fixed inset-0 flex items-center justify-center p-4">
          <form onSubmit={submitWithdraw} className="bg-white rounded-lg p-6 max-w-lg w-full space-y-4">
            <div className="flex justify-between items-center">
              <Dialog.Title className="text-xl font-semibold">Withdraw Funds</Dialog.Title>
              <button onClick={() => setShowWdrModal(false)}><X className="w-6 h-6" /></button>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Withdrawal Method</label>
              <div className="grid grid-cols-2 gap-3">
                {(['bank', 'usdt'] as const).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setWdrMethod(m)}
                    className={`flex items-center justify-center gap-2 p-3 rounded-lg border transition-all ${wdrMethod === m
                      ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-sm'
                      : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                      }`}
                  >
                    {m === 'bank' ? (
                      <>
                        <Landmark className="w-5 h-5" />
                        Bank Transfer
                      </>
                    ) : (
                      <>
                        <CircleDollarSign className="w-5 h-5" />
                        USDT
                      </>
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount (₦)</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₦</span>
                <input
                  type="number"
                  min="1000"
                  max={withdrawable}
                  value={wdrAmt}
                  onChange={e => setWdrAmt(parseFloat(e.target.value))}
                  required
                  className="pl-8 pr-4 py-2 block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <p className="mt-1 text-xs text-gray-500">
                Minimum withdrawal: ₦1,000
              </p>
            </div>

            {wdrMethod === 'bank' ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={wdrBankName}
                    onChange={e => setWdrBankName(e.target.value)}
                    required
                    className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g. Access Bank"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                    <input
                      type="text"
                      value={wdrAcctNum}
                      onChange={e => setWdrAcctNum(e.target.value)}
                      required
                      className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="10 digits"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Account Name</label>
                    <input
                      type="text"
                      value={wdrAcctName}
                      onChange={e => setWdrAcctName(e.target.value)}
                      required
                      className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="As it appears on bank"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">USDT Address</label>
                  <input
                    type="text"
                    value={wdrUsdtAddr}
                    onChange={e => setWdrUsdtAddr(e.target.value)}
                    required
                    className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500 font-mono"
                    placeholder="TXXXXXXXXXXXXXXXXXXX"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Network</label>
                  <select
                    value={wdrUsdtNet}
                    onChange={e => setWdrUsdtNet(e.target.value)}
                    required
                    className="block w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select network</option>
                    <option value="TRC20">TRC20</option>
                    <option value="ERC20">ERC20</option>
                    <option value="BEP20">BEP20</option>
                  </select>
                  <p className="mt-1 text-xs text-gray-500">
                    Ensure network matches your wallet
                  </p>
                </div>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowWdrModal(false)}
                className="px-5 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition flex items-center gap-2"
                disabled={loading}
              >
                {loading ? 'Processing...' : 'Withdraw Funds'}
              </button>
            </div>
          </form>
        </Dialog.Panel>
      </Dialog>
    </div>
  );
}
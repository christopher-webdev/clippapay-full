// routes/clipping.js
// All clipper-facing routes for ClippingCampaign (the "clipping" campaign type)
import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import mongoose from 'mongoose';

import ClippingCampaign from '../models/ClippingCampaign.js';
import ClipSubmission from '../models/ClipSubmission.js';
import Wallet from '../models/Wallet.js';
import Transaction from '../models/Transaction.js';
import { requireAuth, requireClipper } from '../middleware/auth.js';

const router = express.Router();

// ─── Multer config for proof uploads ────────────────────────────────────────
const proofDir = path.join(process.cwd(), 'uploads/clipping-proofs');
fs.mkdirSync(proofDir, { recursive: true });

const proofStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, proofDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniq = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, uniq + ext);
  },
});
const uploadProof = multer({
  storage: proofStorage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB
});
const getRelPath = (f) =>
  f ? `/uploads/clipping-proofs/${path.basename(f.path)}` : undefined;


// ─── BROWSE ─────────────────────────────────────────────────────────────────

/**
 * GET /api/clipping/available
 * List active clipping campaigns a clipper can browse & join.
 * Query params: search, platforms (comma-sep), categories (comma-sep),
 *               sortBy (newest|budget_high|budget_low|cpm_high), page, limit
 */
router.get('/available', requireAuth, async (req, res) => {
  try {
    const {
      search = '',
      platforms = '',
      categories = '',
      sortBy = 'newest',
      page = 1,
      limit = 10,
    } = req.query;

    const filter = { status: 'active' };

    if (search) {
      filter.title = { $regex: search, $options: 'i' };
    }
    if (platforms) {
      filter.platforms = { $in: platforms.split(',').map((p) => p.trim()) };
    }
    if (categories) {
      filter.categories = { $in: categories.split(',').map((c) => c.trim()) };
    }

    const sortMap = {
      newest: { createdAt: -1 },
      budget_high: { budget: -1 },
      budget_low: { budget: 1 },
      cpm_high: { costPerThousand: -1 },
    };
    const sort = sortMap[sortBy] || sortMap.newest;

    const skip = (Number(page) - 1) * Number(limit);

    const [campaigns, total] = await Promise.all([
      ClippingCampaign.find(filter)
        .populate('advertiser', 'firstName lastName company email')
        .sort(sort)
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      ClippingCampaign.countDocuments(filter),
    ]);

    // Annotate each campaign with whether this clipper has already joined
    const clipperId = req.user._id;
    const campaignIds = campaigns.map((c) => c._id);
    const joined = await ClipSubmission.find({
      campaign: { $in: campaignIds },
      clipper: clipperId,
    })
      .select('campaign')
      .lean();
    const joinedSet = new Set(joined.map((j) => j.campaign.toString()));

    const enriched = campaigns.map((c) => ({
      ...c,
      hasJoined: joinedSet.has(c._id.toString()),
      remainingBudget: c.budget - (c.totalSpent || 0),
      completionPct:
        c.estimatedViews > 0
          ? Math.min(100, Math.round(((c.totalViews || 0) / c.estimatedViews) * 100))
          : 0,
    }));

    res.json({
      campaigns: enriched,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / Number(limit)),
    });
  } catch (err) {
    console.error('clipping/available error:', err);
    res.status(500).json({ error: 'Could not fetch campaigns.' });
  }
});

/**
 * GET /api/clipping/stats
 * Quick numbers shown in the browse header.
 */
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const [totalCampaigns, budgetAgg] = await Promise.all([
      ClippingCampaign.countDocuments({ status: 'active' }),
      ClippingCampaign.aggregate([
        { $match: { status: 'active' } },
        { $group: { _id: null, totalBudget: { $sum: '$budget' } } },
      ]),
    ]);
    res.json({
      totalCampaigns,
      totalBudget: budgetAgg[0]?.totalBudget || 0,
    });
  } catch (err) {
    console.error('clipping/stats error:', err);
    res.status(500).json({ error: 'Could not fetch stats.' });
  }
});

/**
 * GET /api/clipping/:id
 * Full details for a single active clipping campaign.
 */
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const campaign = await ClippingCampaign.findById(req.params.id)
      .populate('advertiser', 'firstName lastName company email')
      .lean();

    if (!campaign) return res.status(404).json({ error: 'Campaign not found.' });
    if (campaign.status !== 'active')
      return res.status(403).json({ error: 'Campaign is not active.' });

    // Check if this clipper has already joined
    const submission = await ClipSubmission.findOne({
      campaign: campaign._id,
      clipper: req.user._id,
    }).lean();

    res.json({
      ...campaign,
      hasJoined: !!submission,
      submission: submission || null,
      remainingBudget: campaign.budget - (campaign.totalSpent || 0),
      completionPct:
        campaign.estimatedViews > 0
          ? Math.min(
              100,
              Math.round(((campaign.totalViews || 0) / campaign.estimatedViews) * 100)
            )
          : 0,
    });
  } catch (err) {
    console.error('clipping/:id error:', err);
    res.status(500).json({ error: 'Could not fetch campaign.' });
  }
});


// ─── JOIN ────────────────────────────────────────────────────────────────────

/**
 * POST /api/clipping/:id/join
 * Clipper joins a campaign. Creates a ClipSubmission doc with empty proofs.
 */
router.post('/:id/join', requireAuth, requireClipper, async (req, res) => {
  try {
    const campaign = await ClippingCampaign.findById(req.params.id);
    if (!campaign) return res.status(404).json({ error: 'Campaign not found.' });
    if (campaign.status !== 'active')
      return res.status(403).json({ error: 'Campaign is not active.' });

    // Budget guard — don't let new clippers join if campaign is essentially spent
    const remaining = campaign.budget - (campaign.totalSpent || 0);
    if (remaining <= 0)
      return res.status(403).json({ error: 'Campaign budget is fully used.' });

    const clipperId = req.user._id;

    let submission = await ClipSubmission.findOne({
      campaign: campaign._id,
      clipper: clipperId,
    });

    if (submission) {
      return res.status(200).json({ message: 'Already joined.', submission });
    }

    // Create submission using ClipSubmission model but with a virtual
    // reference to ClippingCampaign via campaign field.
    // We store clipping campaign id — the model uses ref:'Campaign' but
    // MongoDB stores just the ObjectId, so this works cross-collection.
    submission = await ClipSubmission.create({
      campaign: campaign._id,
      clipper: clipperId,
      proofs: [],
    });

    // Increment counter on campaign
    await ClippingCampaign.findByIdAndUpdate(campaign._id, {
      $inc: { clipsCreated: 1 },
    });

    res.status(201).json({ message: 'Joined successfully!', submission });
  } catch (err) {
    console.error('clipping/join error:', err);
    res.status(500).json({ error: 'Could not join campaign.' });
  }
});


// ─── SUBMIT PROOF (initial post) ─────────────────────────────────────────────

/**
 * POST /api/clipping/:id/submit-proof
 * Clipper submits their first proof for a platform.
 * Body: { platform, submissionUrl?, views }
 * Files (optional): proofVideo, proofImage
 *
 * Rules:
 *  - WhatsApp  → no URL, needs proofVideo or proofImage
 *  - All others → submissionUrl (https://...) required
 *  - One proof per platform per clipper
 */
router.post(
  '/:id/submit-proof',
  requireAuth,
  requireClipper,
  uploadProof.any(),
  async (req, res) => {
    try {
      const { platform, submissionUrl, views } = req.body;
      const campaignId = req.params.id;
      const clipperId = req.user._id;

      if (!platform) return res.status(400).json({ error: 'Platform is required.' });

      const campaign = await ClippingCampaign.findById(campaignId);
      if (!campaign) return res.status(404).json({ error: 'Campaign not found.' });
      if (campaign.status !== 'active')
        return res.status(403).json({ error: 'Campaign is not active.' });

      // Must have joined first
      const submission = await ClipSubmission.findOne({
        campaign: campaignId,
        clipper: clipperId,
      });
      if (!submission)
        return res
          .status(403)
          .json({ error: 'You must join the campaign before submitting.' });

      const platformLower = platform.trim().toLowerCase();

      // Check platform is allowed
      const allowed = (campaign.platforms || []).map((p) => p.toLowerCase());
      if (allowed.length && !allowed.includes(platformLower)) {
        return res
          .status(400)
          .json({ error: `Platform "${platform}" is not allowed for this campaign.` });
      }

      // One proof per platform
      const alreadyHas = submission.proofs.some(
        (p) => p.platform?.toLowerCase() === platformLower
      );
      if (alreadyHas) {
        return res.status(409).json({
          error: `You already submitted for ${platform}. Use the "Update Views" option instead.`,
        });
      }

      const proofVideoFile = req.files?.find((f) => f.fieldname === 'proofVideo');
      const proofImageFile = req.files?.find((f) => f.fieldname === 'proofImage');
      const proofVideo = getRelPath(proofVideoFile);
      const proofImage = getRelPath(proofImageFile);
      const viewsNum = Number(views) || 0;
      const isWhatsApp = platformLower === 'whatsapp';

      if (isWhatsApp) {
        if (submissionUrl)
          return res
            .status(400)
            .json({ error: 'WhatsApp submissions cannot include a URL.' });
        if (!proofVideo && !proofImage)
          return res
            .status(400)
            .json({ error: 'WhatsApp requires a screenshot or video proof.' });
      } else {
        if (!submissionUrl?.trim())
          return res.status(400).json({ error: 'Post URL is required.' });
        if (!/^https:\/\//i.test(submissionUrl.trim()))
          return res.status(400).json({ error: 'Post URL must start with https://' });

        // Global duplicate URL check
        const dup = await ClipSubmission.findOne({
          'proofs.submissionUrl': submissionUrl.trim(),
          'proofs.platform': { $ne: 'WhatsApp' },
        });
        if (dup)
          return res
            .status(409)
            .json({ error: 'This link has already been submitted by another clipper.' });
      }

      submission.proofs.push({
        platform: platform.trim(),
        submissionUrl: isWhatsApp ? null : submissionUrl.trim(),
        views: viewsNum,
        proofVideo,
        proofImage,
        status: 'pending',
        verifiedViews: 0,
        rewardAmount: 0,
      });

      await submission.save();

      res.status(201).json({ message: 'Proof submitted!', submission });
    } catch (err) {
      console.error('clipping/submit-proof error:', err);
      res.status(500).json({ error: 'Could not submit proof.' });
    }
  }
);


// ─── UPDATE VIEWS (view count grown) ─────────────────────────────────────────

/**
 * PATCH /api/clipping/submissions/:submissionId/proofs/:proofId/update-views
 * Clipper updates the view count on an existing proof (re-queues for admin review).
 * Body: { views }
 * Files (optional): proofVideo, proofImage (screenshot evidence)
 */
router.patch(
  '/submissions/:submissionId/proofs/:proofId/update-views',
  requireAuth,
  requireClipper,
  uploadProof.any(),
  async (req, res) => {
    try {
      const { submissionId, proofId } = req.params;
      const { views, submissionUrl } = req.body;

      const submission = await ClipSubmission.findById(submissionId);
      if (!submission) return res.status(404).json({ error: 'Submission not found.' });
      if (String(submission.clipper) !== String(req.user._id))
        return res.status(403).json({ error: 'Not your submission.' });

      const proof = submission.proofs.id(proofId);
      if (!proof) return res.status(404).json({ error: 'Proof not found.' });

      const newViews = Number(views);
      if (!views || isNaN(newViews) || newViews <= 0)
        return res.status(400).json({ error: 'A valid view count is required.' });

      if (newViews <= (proof.verifiedViews || 0)) {
        return res.status(400).json({
          error: `New view count (${newViews.toLocaleString()}) must be higher than the last verified count (${(proof.verifiedViews || 0).toLocaleString()}).`,
        });
      }

      const proofVideo = getRelPath(req.files?.find((f) => f.fieldname === 'proofVideo'));
      const proofImage = getRelPath(req.files?.find((f) => f.fieldname === 'proofImage'));

      proof.views = newViews;
      if (proofVideo) proof.proofVideo = proofVideo;
      if (proofImage) proof.proofImage = proofImage;
      if (submissionUrl?.trim()) {
        if (!/^https:\/\//i.test(submissionUrl.trim()))
          return res.status(400).json({ error: 'URL must start with https://' });
        proof.submissionUrl = submissionUrl.trim();
      }

      // Re-queue for admin verification
      proof.status = 'pending';

      await submission.save();

      res.json({ message: 'View count updated. Awaiting admin verification.', submission });
    } catch (err) {
      console.error('update-views error:', err);
      res.status(500).json({ error: 'Could not update view count.' });
    }
  }
);


// ─── MY CLIPPING SUBMISSIONS ─────────────────────────────────────────────────

/**
 * GET /api/clipping/my/submissions
 * All clipping submissions for the logged-in clipper.
 */
router.get('/my/submissions', requireAuth, requireClipper, async (req, res) => {
  try {
    // Get all ClipSubmissions whose campaign is a ClippingCampaign
    const subs = await ClipSubmission.find({ clipper: req.user._id })
      .sort({ createdAt: -1 })
      .lean();

    // Hydrate campaign info from ClippingCampaign
    const campaignIds = subs.map((s) => s.campaign);
    const campaigns = await ClippingCampaign.find({ _id: { $in: campaignIds } })
      .select('title status budget totalSpent totalViews estimatedViews costPerThousand currency platforms')
      .lean();
    const campMap = Object.fromEntries(campaigns.map((c) => [c._id.toString(), c]));

    const formatted = subs
      .map((s) => {
        const camp = campMap[s.campaign?.toString()];
        if (!camp) return null; // not a clipping campaign submission

        const approvedProofs = (s.proofs || []).filter((p) => p.status === 'approved');
        const totalVerifiedViews = approvedProofs.reduce(
          (acc, p) => acc + (p.verifiedViews || 0),
          0
        );
        const totalEarned = approvedProofs.reduce(
          (acc, p) => acc + (p.rewardAmount || 0),
          0
        );
        const pendingProofs = (s.proofs || []).filter((p) => p.status === 'pending').length;

        return {
          ...s,
          campaign: {
            _id: camp._id,
            title: camp.title,
            status: camp.status,
            currency: camp.currency,
            costPerThousand: camp.costPerThousand,
            platforms: camp.platforms,
          },
          totalVerifiedViews,
          totalEarned,
          pendingProofs,
        };
      })
      .filter(Boolean);

    res.json(formatted);
  } catch (err) {
    console.error('my/submissions error:', err);
    res.status(500).json({ error: 'Could not fetch submissions.' });
  }
});


// ─── ADMIN: Approve / reject a clipping proof & credit wallet ────────────────

/**
 * PATCH /api/clipping/admin/submissions/:submissionId/proofs/:proofId/review
 * Admin approves or rejects a proof and (on approval) calculates reward.
 * Body: { action: 'approve'|'reject', adminNote?, verifiedViews? }
 */
router.patch(
  '/admin/submissions/:submissionId/proofs/:proofId/review',
  requireAuth,
  async (req, res) => {
    if (req.user.role !== 'admin')
      return res.status(403).json({ error: 'Admins only.' });

    try {
      const { submissionId, proofId } = req.params;
      const { action, adminNote, verifiedViews } = req.body;

      if (!['approve', 'reject'].includes(action))
        return res.status(400).json({ error: 'action must be "approve" or "reject".' });

      const submission = await ClipSubmission.findById(submissionId);
      if (!submission) return res.status(404).json({ error: 'Submission not found.' });

      const proof = submission.proofs.id(proofId);
      if (!proof) return res.status(404).json({ error: 'Proof not found.' });

      // Fetch the clipping campaign for CPM rate
      const campaign = await ClippingCampaign.findById(submission.campaign);
      if (!campaign) return res.status(404).json({ error: 'Campaign not found.' });

      if (action === 'reject') {
        proof.status = 'rejected';
        proof.adminNote = adminNote || '';
        await submission.save();
        return res.json({ message: 'Proof rejected.', submission });
      }

      // ── APPROVE ──
      const newVerified = Number(verifiedViews) || proof.views;
      const previousVerified = proof.verifiedViews || 0;
      const incrementalViews = Math.max(0, newVerified - previousVerified);

      // Reward = incremental views × (CPM / 1000)
      const incrementalReward = (incrementalViews * campaign.costPerThousand) / 1000;

      proof.status = 'approved';
      proof.adminNote = adminNote || '';
      proof.verifiedViews = newVerified;
      proof.rewardAmount = (proof.rewardAmount || 0) + incrementalReward;
      proof.lastVerified = new Date();

      // Update campaign totals
      await ClippingCampaign.findByIdAndUpdate(campaign._id, {
        $inc: {
          totalViews: incrementalViews,
          totalSpent: incrementalReward,
        },
      });

      // Credit clipper wallet
      if (incrementalReward > 0) {
        let wallet = await Wallet.findOne({ user: submission.clipper });
        if (!wallet) wallet = await Wallet.create({ user: submission.clipper, balance: 0 });

        wallet.balance += incrementalReward;
        await wallet.save();

        await Transaction.create({
          user: submission.clipper,
          type: 'clipping_reward',
          amount: incrementalReward,
          currency: campaign.currency,
          description: `Clipping reward — ${proof.platform} — ${incrementalViews.toLocaleString()} views`,
          status: 'completed',
          reference: `CLIP-${submissionId}-${proofId}-${Date.now()}`,
        });

        submission.rewardAmount = (submission.rewardAmount || 0) + incrementalReward;
      }

      await submission.save();

      res.json({
        message: `Proof approved. Clipper credited ${campaign.currency === 'NGN' ? '₦' : '$'}${incrementalReward.toFixed(2)}.`,
        submission,
      });
    } catch (err) {
      console.error('admin review error:', err);
      res.status(500).json({ error: 'Could not review proof.' });
    }
  }
);

export default router;
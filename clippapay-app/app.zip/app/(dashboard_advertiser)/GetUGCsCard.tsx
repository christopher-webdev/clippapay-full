// app/components/GetUGCsCard.tsx
import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';

const { width } = Dimensions.get('window');
const scale = width / 428;

export default function GetUGCsCard() {
  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={styles.cardOuter}
      onPress={() => router.push('/onboarding_ugc')} // ← your route
    >
      <View style={styles.cardWrapper}>
        {/* Gradient inner card */}
        <LinearGradient
          colors={['#605C3C', '#3C3B3F']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.gradient}
        >
          {/* Banner tab (yellowish, sticks out left) */}
          <View style={styles.bannerContainer}>
            <View style={styles.bannerBackground} />
            <View style={styles.bannerTextWrapper}>
              <Text style={styles.bannerText}>
                Get Videos for My Brand
              </Text>
            </View>
          </View>

          {/* Main title */}
          <Text style={styles.title}>
            Order custom{'\n'}UGCs{'\n'}for your brand.
          </Text>

          {/* Megaphone guy – positioned on right, overlapping */}
          <Image
            source={require('../../assets/images/megaphone_guy.png')}
            style={styles.megaphone}
            resizeMode="contain"
          />

          {/* CTA link */}
          <Text style={styles.cta}>
            View Standard Creators →
          </Text>
        </LinearGradient>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  cardOuter: {
    width: 390 * scale,
    height: 230 * scale,
    alignSelf: 'center',
    marginTop: 5 * scale, 
  },
  cardWrapper: {
    flex: 1,
    borderRadius: 10 * scale,
    overflow: 'hidden',
    shadowColor: '#fcfcfc',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  gradient: {
    flex: 1,
    borderRadius: 10 * scale,
  },

  // Banner (desired tab effect)
  bannerContainer: {
    position: 'absolute',
    top: 0,
    left: 51 * scale,
    width: 285 * scale,
    height: 37 * scale,
    zIndex: 2,
  },
  bannerBackground: {
    flex: 1,
    backgroundColor: '#D6CF8D80',
    borderTopRightRadius: 1 * scale,
    borderBottomRightRadius: 100 * scale,
    borderBottomLeftRadius: 100 * scale,
  },
  bannerTextWrapper: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    paddingLeft: 33 * scale, // offset to center text nicely
  },
  bannerText: {
    // fontFamily: 'OpenSans',
    fontWeight: '700',
    fontSize: 14 * scale,
    color: '#ffffff',
    lineHeight: 19.6 * scale, // 140%
    letterSpacing: 0.2 * scale,
  },

  // Title with line break for better fit
  title: {
    position: 'absolute',
    top: 64 * scale,
    left: 29 * scale,
    // fontFamily: 'OpenSans',
    fontWeight: '700',
    fontSize: 20 * scale,
    lineHeight: 28 * scale,
    letterSpacing: 0.2 * scale,
    color: '#FFFFFF',
  },

  // Megaphone image (right-aligned, tall)
  megaphone: {
    position: 'absolute',
    top: 30 * scale,
    right: -150,
    width: 452 * scale,
    height: 206 * scale,
  },

  // CTA at bottom-left
  cta: {
    position: 'absolute',
    bottom: 28 * scale, // roughly matches ~174px from top in 215px inner height
    left: 29 * scale,
    // fontFamily: 'OpenSans',
    fontWeight: '700',
    fontSize: 12 * scale,
    color: '#FFFFFF',
    lineHeight: 16.8 * scale,
    letterSpacing: 0.2 * scale,
  },
});